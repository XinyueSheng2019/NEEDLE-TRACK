"""
needle_track_XinyueAstro - Transient Recognition, Annotation, and Classification Kit
"""

__version__ = "0.1.0"
__author__ = "Xinyue Sheng"

from needle_track_XinyueAstro.core import * 